package com.counter.api.controllers;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.counter.api.pojo.WordSearch;
import com.counter.api.pojo.WordSearchOutput;
import com.counter.api.services.WordServices;
import com.counter.api.utils.CsvResponse;

/**
 * The Main Controller which would take all the requests 
 * And Provide results for Search and Top 
 * @author faraz
 *
 */

@Controller
@RequestMapping("/")
public class WordProcessController {

	@RequestMapping(value="/search",method=RequestMethod.POST)
	public @ResponseBody WordSearchOutput getWordSearch(@RequestBody WordSearch words){
		Map<String,Integer> map = WordServices.getWordsForKeys(words.getSearchText());
		WordSearchOutput output = new WordSearchOutput();
		output.setCounts(map);
		return output;
	}
	
	@RequestMapping(value="/top/{toplist}",method=RequestMethod.GET)
	public @ResponseBody CsvResponse getTopWords(@PathVariable int toplist){
		List<Entry<String,Integer>> list = WordServices.getTopWords(toplist);
		CsvResponse response = new CsvResponse();
		response.setRecords(list);
		return response;
	}
}
