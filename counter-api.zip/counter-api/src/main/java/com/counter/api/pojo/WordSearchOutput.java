package com.counter.api.pojo;

import java.io.Serializable;
import java.util.Map;

/**
 * This would be the Output for the Words
 * @author faraz
 *
 */
public class WordSearchOutput implements Serializable{

	private Map<String,Integer> counts;

	public Map<String, Integer> getCounts() {
		return counts;
	}

	public void setCounts(Map<String, Integer> counts) {
		this.counts = counts;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((counts == null) ? 0 : counts.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WordSearchOutput other = (WordSearchOutput) obj;
		if (counts == null) {
			if (other.counts != null)
				return false;
		} else if (!counts.equals(other.counts))
			return false;
		return true;
	}
	
	
	
}
