package com.counter.api.utils;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;

import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.converter.AbstractHttpMessageConverter;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;

import au.com.bytecode.opencsv.CSVWriter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * Converter for the HTTP to CSV
 * @author faraz
 *
 */
public class CsvConverter extends AbstractHttpMessageConverter<CsvResponse>{
	
	 public static final MediaType MEDIA_TYPE = new MediaType("text", "csv", Charset.forName("utf-8"));
	   public CsvConverter() {
	       super(MEDIA_TYPE);
	   }

	   protected boolean supports(Class<?> clazz) {
	       return CsvResponse.class.equals(clazz);
	   }

	   protected void writeInternal(CsvResponse response, HttpOutputMessage output) throws IOException, HttpMessageNotWritableException {
	       output.getHeaders().setContentType(MEDIA_TYPE);
	       OutputStream out = output.getBody();
	       CSVWriter writer = new CSVWriter(new OutputStreamWriter(out),'\u0009');
	       List<Entry<String,Integer>> allRecords = response.getRecords();
	       List<String[]> temp = new ArrayList<String[]>();
	       for (int i = 1; i < allRecords.size(); i++) {
	    	  // writer.writeNext(arg0);
	    	   String[] x = new String[]{allRecords.get(i).getKey()+"|"+allRecords.get(i).getValue()};
	    	   temp.add(x);
	       }
	       writer.writeAll(temp);
	       writer.close();
	   }

	@Override
	protected CsvResponse readInternal(Class<? extends CsvResponse> arg0,
			HttpInputMessage arg1) throws IOException,
			HttpMessageNotReadableException {
		// TODO Auto-generated method stub
		return null;
	}
}
