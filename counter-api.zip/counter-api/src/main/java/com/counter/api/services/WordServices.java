package com.counter.api.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.counter.api.dataobjects.WordDataObjects;

/**
 * Services
 * @author faraz
 *
 */
public class WordServices {
	
	public static Map<String,Integer> getWordsForKeys(List<String> keys){
		Map<String,Integer> allKeyWords = WordDataObjects.getProxyMap();
		Map<String,Integer> keyOutput = new HashMap<String, Integer>();
		for(String key : keys){
			if(allKeyWords.containsKey(key)){
				keyOutput.put(key, allKeyWords.get(key));
			}else{
				keyOutput.put(key, 0);
			}
		}
		
		return keyOutput;
	}
	
	public static List<Entry<String,Integer>> getTopWords(int topList){
		Map<String,Integer> map = WordDataObjects.getProxyMap();
		Set<Entry<String,Integer>> set = map.entrySet();
		List<Entry<String,Integer>> list = new ArrayList<Entry<String,Integer>>(set);
		Collections.sort(list,new Comparator<Entry<String,Integer>>() {

			public int compare(Entry<String, Integer> o1,
					Entry<String, Integer> o2) {
				return o2.getValue().compareTo(o1.getValue());
			}
		});
		
		List<Entry<String,Integer>> sublist = new ArrayList<Entry<String,Integer>>();
		if(list.size() > topList){
			sublist = list.subList(0, topList);
		}
		return sublist;
	}

}
