package com.counter.api.dataobjects;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/**
 * This would fetch data from DataFile for the Given problem.
 * @author faraz
 *
 */
public class WordDataObjects {
	
	public static Map<String,Integer> wordMap = new HashMap<String,Integer>();
	
	private static void getDataFromFile(){
		try {
			URI uri = WordDataObjects.class.getClassLoader().getResource("DataFile.txt").toURI();
			File file = new File(uri);
			FileReader fileReader = new FileReader(file);
			BufferedReader reader = new BufferedReader(fileReader);
			String line;
			while((line=reader.readLine())!=null){
				String[] wordsinLine = line.replace(",","").split(" ");
				for(String keyword : wordsinLine){
					if(keyword !=null && !"".equals(keyword.trim())){
						if(wordMap.containsKey(keyword)){
							int count = wordMap.get(keyword);
							count++;
							wordMap.put(keyword, count);
						}else{
							wordMap.put(keyword, 1);
						}
					}
				}
			}
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static Map<String,Integer> getProxyMap(){
		if(wordMap.isEmpty()){
			getDataFromFile();
		}
		return wordMap;
	}

	public static void main(String[] ats){
		getDataFromFile();
		for(Entry<String,Integer> set : wordMap.entrySet()){
			System.out.println(set.getKey() +"="+set.getValue());
		}
	}
	
}
