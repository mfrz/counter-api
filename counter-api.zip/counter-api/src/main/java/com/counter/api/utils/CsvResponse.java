package com.counter.api.utils;

import java.util.List;
import java.util.Map.Entry;

/**
 * CSV response object
 * @author faraz
 *
 */
public class CsvResponse {
	   
	private List<Entry<String,Integer>> records;

	public List<Entry<String, Integer>> getRecords() {
		return records;
	}

	public void setRecords(List<Entry<String, Integer>> records) {
		this.records = records;
	}
	
}
